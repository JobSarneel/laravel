@extends('layouts.master')

@section('contentHeading')
	Logout
@endsection

@section('content')
	Ingelogde gebruikers kunnen hier uitloggen.
@endsection

<!-- @section('sidebar')
	@parent
@endsection -->
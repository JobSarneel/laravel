@extends('layouts.master')

@section('contentHeading')
	Home
@endsection

@section('content')
	Landingspagina voor geregistreerden <i>I suppose</i>...
	Nee, want geen nieuwe mysql entry...
@endsection

<!-- @section('sidebar')
	@parent
@endsection -->
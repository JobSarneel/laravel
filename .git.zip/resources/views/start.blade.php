@extends('layouts.master')

@section('contentHeading')
	Homepage
@endsection

@section('content')
	Dit is de landingspagina. Op dit moment is de gebruiker nog niet ingelogd.
@endsection

<!-- @section('sidebar')
	@parent
@endsection -->
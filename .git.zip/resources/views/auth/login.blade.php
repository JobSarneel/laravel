@extends('layouts.master')

@section('contentHeading')
	Login
@endsection

@section('content')
	Hier kunnen geregistreerde gebruikers inloggen om toegang te krijgen tot het 'members-only' gedeelte.
@endsection

<!-- @section('sidebar')
	@parent
@endsection -->
@extends('layouts.master')

@section('contentHeading')
	Members only
@endsection

@section('content')
	Alleen ingelogde gebruikers kunnen deze pagina bezoeken.
@endsection

<!-- @section('sidebar')
	@parent
@endsection -->